{
    "A.Thousand.Blows": {
        "S01": {
            "E01": {
                "480p WEB DL SoftSub": "https://dl6.digimoviz.top/www2/series/A.Thousand.Blows/s01/A.Thousand.Blows.S01E01.480p.WEB-DL.SoftSub.DigiMoviez.mkv?md5=c8RJUeVMMgSDc-Les6xaMA&expires=1740518447"
            },
            "E02": {
                "1080p WEB DL SoftSub": "https://dl6.digimoviz.top/www2/series/A.Thousand.Blows/s01/A.Thousand.Blows.S01E02.1080p.WEB-DL.SoftSub.DigiMoviez.mkv?md5=WIdp5ejLy50QJlsqoz70Bg&expires=1740518447",
                "720p WEB DL SoftSub": "https://dl6.digimoviz.top/www2/series/A.Thousand.Blows/s01/A.Thousand.Blows.S01E02.720p.WEB-DL.SoftSub.DigiMoviez.mkv?md5=_3SFss2BR-fN-CUJa2EMRw&expires=1740518447",
                "480p WEB DL SoftSub": "https://dl6.digimoviz.top/www2/series/A.Thousand.Blows/s01/A.Thousand.Blows.S01E02.480p.WEB-DL.SoftSub.DigiMoviez.mkv?md5=rmC2Fws0_R56jHY5lwv4lw&expires=1740518447"
            },
            "E03": {
                "1080p WEB DL SoftSub": "https://dl6.digimoviz.top/www2/series/A.Thousand.Blows/s01/A.Thousand.Blows.S01E03.1080p.WEB-DL.SoftSub.DigiMoviez.mkv?md5=nBWtX_HrWjbR_pO7uViIPQ&expires=1740518447"
            }
        }
    },
    "Interstellar.2014": {
        "IMAX EDITION 1080p BluRay Dubbed": "Interstellar.2014.IMAX.EDITION.1080p.BluRay.Dubbed.DigiMoviez.mkv"
    },
    "Demon.City.2025": {
        "1080p 10bit WEB DL 6CH x265 SoftSub": "https://dl33.digimoviz.top/www2/film/1403/12/Demon.City.2025.1080p.10bit.WEB-DL.6CH.x265.SoftSub.DigiMoviez.mkv?md5=qyY_EKCcsvbv7JsraSXmVg&expires=1741292985"
    }
}