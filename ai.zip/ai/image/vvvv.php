{
    "message": "CSRF token mismatch."
}