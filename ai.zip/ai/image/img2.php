{
  "id": "ntXGxDZ-4yUbBN-93dc17e6ce0dd20b-FRA",
  "error": {
    "message": "Credit limit exceeded. Please navigate to https://api.together.xyz/settings/billing to add credit or upgrade your plan.",
    "type": "credit_limit",
    "param": null,
    "code": null
  }
}