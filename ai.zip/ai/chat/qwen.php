event: error
data: null

