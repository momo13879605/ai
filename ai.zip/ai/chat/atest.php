{
  "error": {
    "code": 400,
    "message": "Invalid JSON payload received. Unknown name \"system_instruction\": Proto field is not repeating, cannot start list.",
    "status": "INVALID_ARGUMENT",
    "details": [
      {
        "@type": "type.googleapis.com/google.rpc.BadRequest",
        "fieldViolations": [
          {
            "description": "Invalid JSON payload received. Unknown name \"system_instruction\": Proto field is not repeating, cannot start list."
          }
        ]
      }
    ]
  }
}
